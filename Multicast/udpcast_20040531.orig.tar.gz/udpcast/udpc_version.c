#include "udpc_version.h"

char *version="2004-05-31";
